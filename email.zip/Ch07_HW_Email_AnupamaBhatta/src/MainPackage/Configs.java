package MainPackage;


/**
 * Author: Anupama Bhatta 
 * Date: 02/25/2019 
 * Description: A Java application that allows sending e-mails.
 */

public class Configs {
    public static final String EMAIL_ACCOUNT = "teststudent@wesleyancollege.edu";
    public static final String EMAIL_ACCOUNT_PASS = "*RCjPn2H";
    
}
