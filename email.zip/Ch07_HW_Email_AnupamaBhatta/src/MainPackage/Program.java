package MainPackage;

/**
* Author: Anupama Bhatta
* Date:   02/25/2019
* Description: A Java application that allows sending e-mails.
*/

public class Program {

    public static void main(String[] args) 
    {          
        new UI_SendEmail().setVisible(true);
    }
    
}
